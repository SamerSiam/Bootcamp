Client ---> request --->Server
Client <--- request <--- Server
//This is called the request-response model or Client-server archititure

https://www.google.com/maps?country=israel&city=holonddress=histradrut&api_key

- https: Protocol
- google.com: Domain name
- /maps: Resource
- ?country=israel: query
- &city=holon: query

  216.58.212.164:443 // https
  216.58.212.164:80 // http
