import React  from 'react';
import './App.css'
import Editing from './Components/Editing/Editing'

const App = () => {



    return (

        <div className="App">
       
        <div> <Editing/></div>
      
        </div>
      

    )    
        
   
}



export default App