import React from 'react';
// import Search from './Components/Search/Search'
import Countries from './Components/Countries/Countries'



const App = () => {



    return <div>
        
       {/* <Search/> */}
       <Countries/>
       
       
        
    </div>
}



export default App