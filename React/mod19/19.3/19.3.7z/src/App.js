import React from 'react';
// import Search from './Components/Search/Search'
// import Countries from './Components/Countries/Countries'
import Algolia from './Components/Algolia/Algolia'



const App = () => {



    return (
        
        <div>
         <Algolia/>
        </div>
      

    )
   
       
       
        
   
}



export default App