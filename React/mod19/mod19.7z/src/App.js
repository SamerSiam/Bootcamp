import React from 'react';
// import Search from './Components/Search/Search'
import Fetch from './Components/StarWars/Fetch'



const App = () => {



    return <div>
        
       {/* <Search/> */}
       <Fetch/>
       
        
    </div>
}



export default App