import React from 'react';
// import Search from './Components/Search/Search'
// import Countries from './Components/Countries/Countries'
import ChuckNorris from './Components/ChuckNorris/ChuckNorris'



const App = () => {



    return (

        <div>
        <ChuckNorris/>
        </div>
      

    )
   
       
       
        
   
}



export default App