const DogCard = ({ url }) => {
  return <img height={200} width={200} src={url} />;
};

export default DogCard;
