import React from "react";
import "./App.css";
import List from "./List";

function App() {
  return (
    <div>
      <List />
    </div>
  );
}

export default App;
