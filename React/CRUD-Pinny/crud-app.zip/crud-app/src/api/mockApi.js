import axios from "axios";

export default axios.create({
  baseURL: "https://605ae66227f0050017c0572d.mockapi.io/",
});
