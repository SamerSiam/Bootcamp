const data = [
  {
    title: "stylish hat",
    imageUrl: "https://i.ibb.co/z8GM1Mh/tie.jpg",
    size: "Fits for all",
    price: 25,
    id: 1,
  },
  {
    title: "Beautiful Jacket",
    imageUrl: "https://i.ibb.co/kq23hr4/jacket.jpg",
    price: 55,
    id: 2,
    size: "Medium",
  },
  {
    title: "Jeans",
    imageUrl: "https://i.ibb.co/C62CZRy/jean.jpg",
    price: 39,
    id: 3,
    size: "Medium",
  },
  {
    title: "Tie",
    imageUrl: "https://i.ibb.co/z8GM1Mh/tie.jpg",
    price: 10,
    id: 4,
    size: "Fits for all",
  },
];

export default data;
