import React from "react";
const NotFound = (props) => {
  return <div>{props.type} 404 Not Found</div>;
};

export default NotFound;
