import axios from "axios";

export default axios.create({
    baseURL:'https://61c307299cfb8f0017a3e8c1.mockapi.io/',
});