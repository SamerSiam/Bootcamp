import React from 'react';

const HomePage = (props) => {

    // const myData=this.props.data;
   

    return (
        <div> 
           
           Customer List
        </div>
    )
};

export default HomePage;